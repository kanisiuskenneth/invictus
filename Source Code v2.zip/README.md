IF2210 Pemrograman Berorientasi Object
Tugas Besar 3 - Kelompok 11 Invictus

Anggota:
- Kanisius Kenneth Halim 13515008
- Andika Kusuma 13515033
- Kezia Suhendra 13515063
- Sylvia Juliana 13515070

System Requirement untuk menjalankan Perangkat Lunak : 
- Display minimal 1280*720
- RAM 2 GB
- Processor Core i3

Cara run: Buka Jar File
Cara Compile : Kompilasi menggunakan IDE, Developer menggunakan Intellij IDEA by Jetbrains.

-InvictusTeam-